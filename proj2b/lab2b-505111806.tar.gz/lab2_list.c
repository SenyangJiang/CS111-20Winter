// NAME: Senyang Jiang
// EMAIL: senyangjiang@yahoo.com
// ID: 505111806

#include <unistd.h>
#include <getopt.h>
#include "SortedList.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>
#include <signal.h>
#include <string.h>

int num_threads = 1;
int num_iter = 1;
int num_lists = 1;
char sync_opt = 'n';
int opt_yield = 0;
SortedListElement_t *elements;

struct Sublist_t {
  SortedList_t head;
  pthread_mutex_t mutexlist;
  volatile int lock;
};

struct Sublist_t* sublists;

void sig_handler(int signo)
{
  fprintf(stderr , "Segmentation Fault! Signal Number:%d\n", signo);
  exit(2);
}

unsigned long
hash(const char *str)
{
    unsigned long hash = 5381;
    int c;

    while ((c = *str++))
        hash = ((hash << 5) + hash) + c; /* hash * 33 + c */

    return hash;
}

void *thread_func(void *thread_id) {
  long tid = (long)thread_id;
  struct timespec start, end;
  long total_time = 0;
  long list_id;
  // inserts them all into a list
  for(int i = tid*num_iter; i < (tid+1)*num_iter; i++) {
    list_id = hash(elements[i].key) % num_lists;
    if(sync_opt == 'm') {
      clock_gettime(CLOCK_MONOTONIC, &start);
      pthread_mutex_lock(&(sublists[list_id].mutexlist));
      clock_gettime(CLOCK_MONOTONIC, &end);
      total_time += (end.tv_sec - start.tv_sec)*1000000000 + (end.tv_nsec - start.tv_nsec);
      SortedList_insert(&(sublists[list_id].head), &elements[i]);
      pthread_mutex_unlock(&(sublists[list_id].mutexlist));
    }
    else if(sync_opt == 's') {
      clock_gettime(CLOCK_MONOTONIC, &start);
      while (__sync_lock_test_and_set(&(sublists[list_id].lock), 1));
      clock_gettime(CLOCK_MONOTONIC, &end);
      total_time += (end.tv_sec - start.tv_sec)*1000000000 + (end.tv_nsec - start.tv_nsec);
      SortedList_insert(&(sublists[list_id].head), &elements[i]);
      __sync_lock_release(&(sublists[list_id].lock));
    }
    else{
      SortedList_insert(&(sublists[list_id].head), &elements[i]);
    }
  }
  // get the list length
  int total_len = 0;
  int len = 0;
  for(int i = 0; i < num_lists; i++) {
    if(sync_opt == 'm') {
      clock_gettime(CLOCK_MONOTONIC, &start);
      pthread_mutex_lock(&(sublists[i].mutexlist));
      clock_gettime(CLOCK_MONOTONIC, &end);
      total_time += (end.tv_sec - start.tv_sec)*1000000000 + (end.tv_nsec - start.tv_nsec);
      len = SortedList_length(&(sublists[i].head));
      pthread_mutex_unlock(&(sublists[i].mutexlist));
    }
    else if(sync_opt == 's') {
      clock_gettime(CLOCK_MONOTONIC, &start);
      while (__sync_lock_test_and_set(&(sublists[i].lock), 1));
      clock_gettime(CLOCK_MONOTONIC, &end);
      total_time += (end.tv_sec - start.tv_sec)*1000000000 + (end.tv_nsec - start.tv_nsec);
      len = SortedList_length(&(sublists[i].head));
      __sync_lock_release(&(sublists[i].lock));
    }
    else{
      len = SortedList_length(&(sublists[i].head));
    }

    if(len == -1) {
      fprintf(stderr, "Failure in finding list length\n");
      exit(2);
    }
    total_len += len;
  }
  // looks up and deletes each of the keys it had previously inserted
  for(int i = tid*num_iter; i < (tid+1)*num_iter; i++) {
    SortedListElement_t *e;
    int rc;
    list_id = hash(elements[i].key) % num_lists;
    if(sync_opt == 'm') {
      clock_gettime(CLOCK_MONOTONIC, &start);
      pthread_mutex_lock(&(sublists[list_id].mutexlist));
      clock_gettime(CLOCK_MONOTONIC, &end);
      total_time += (end.tv_sec - start.tv_sec)*1000000000 + (end.tv_nsec - start.tv_nsec);
      e = SortedList_lookup(&(sublists[list_id].head), elements[i].key);
      if(e == NULL) {
	fprintf(stderr, "Failure in looking up list element\n");
	exit(2);
      }
      rc = SortedList_delete(e);
      if(rc == 1) {
	fprintf(stderr, "Failure in deleting list element\n");
	exit(2);
      }
      pthread_mutex_unlock (&(sublists[list_id].mutexlist));
    }
    else if(sync_opt == 's') {
      clock_gettime(CLOCK_MONOTONIC, &start);
      while (__sync_lock_test_and_set(&(sublists[list_id].lock), 1));
      clock_gettime(CLOCK_MONOTONIC, &end);
      total_time += (end.tv_sec - start.tv_sec)*1000000000 + (end.tv_nsec - start.tv_nsec);
      e = SortedList_lookup(&(sublists[list_id].head), elements[i].key);
      if(e == NULL) {
	fprintf(stderr, "Failure in looking up list element\n");
	exit(2);
      }
      rc = SortedList_delete(e);
      if(rc == 1) {
	fprintf(stderr, "Failure in deleting list element\n");
	exit(2);
      }
      __sync_lock_release(&(sublists[list_id].lock));
    }
    else{
      e = SortedList_lookup(&(sublists[list_id].head), elements[i].key);
      if(e == NULL) {
	fprintf(stderr, "Failure in looking up list element\n");
	exit(2);
      }
      rc = SortedList_delete(e);
      if(rc == 1) {
	fprintf(stderr, "Failure in deleting list element\n");
	exit(2);
      }
    }
  }
  pthread_exit((void *)total_time);
}
int main(int argc, char **argv)
{
  int opt;
  struct option long_options[] = {{"threads", required_argument, NULL, 't'},
                                  {"iterations", required_argument, NULL, 'i'},
                                  {"yield", required_argument, NULL, 'y'},
                                  {"sync", required_argument, NULL, 's'},
				  {"lists", required_argument, NULL, 'l'},
                                  {0, 0, 0, 0}};
  int len;
  while(1)
    {
      opt = getopt_long(argc, argv, "+:", long_options, NULL);
      if(opt == -1)
        break;

      switch(opt)
        {
	case 'l':
	  num_lists = atoi(optarg);
	  break;
	case 's':
	  sync_opt = optarg[0];
	  if(sync_opt != 'm' && sync_opt != 's') {
	    fprintf(stderr, "invalid sync option\n");
	    exit(1);
	  }
	  break;
        case 'y':
	  len = strlen(optarg);
          for(int i = 0; i < len; i++) {
	    if(optarg[i] == 'i')
	      opt_yield |= INSERT_YIELD;
	    else if(optarg[i] == 'd')
	      opt_yield |= DELETE_YIELD;
	    else if(optarg[i] == 'l')
	      opt_yield |= LOOKUP_YIELD;
	    else {
	      fprintf(stderr, "invalid yield option\n");
	      exit(1);
	    }
	  }
          break;
        case 't':
          num_threads = atoi(optarg);
          break;
        case 'i':
          num_iter = atoi(optarg);
          break;
        case '?':
          fprintf(stderr, "Unrecognized argument: %s\n", argv[optind-1]);
          exit(1);
          break;
        case ':':
          fprintf(stderr, "Missing argument for %s\n", argv[optind-1]);
          exit(1);
          break;
        }
    }

  // check if there is an element that is not an option
  if(optind != argc)
    {
      fprintf(stderr, "Unrecognized argument: %s\n", argv[optind]);
      exit(1);
    }

  // register a segmentation fault handler
  signal(SIGSEGV, sig_handler);

  // create the specified number of empty sublists
  sublists = malloc(sizeof(struct Sublist_t)*num_lists);
  if(sublists == NULL) {
    fprintf(stderr, "Fail to allocate space for sublists\n");
    exit(1);
  }
  for(int i = 0; i < num_lists; i++) {
    sublists[i].head.key = NULL;
    sublists[i].head.next = &(sublists[i].head);
    sublists[i].head.prev = &(sublists[i].head);
  }
  
  // initialize mutex if required
  if(sync_opt == 'm') {
    for(int i = 0; i < num_lists; i++) {
      if(pthread_mutex_init(&(sublists[i].mutexlist), NULL) != 0) {
	fprintf(stderr, "Fail to initialize mutex\n");
	exit(1);
      }
    }
  }

  // initialize lock variable if required
  if(sync_opt == 's') {
    for(int i = 0; i < num_lists; i++) {
      sublists[i].lock = 0;
    }
  }

  // initialize the required number of list elements with random keys(printable ASCII strings)
  long num_elements = num_threads * num_iter;
  elements = malloc(sizeof(SortedListElement_t)*num_elements);
  if(elements == NULL) {
    fprintf(stderr, "Fail to allocate space for list elements\n");
    exit(1);
  }
  char **keys = malloc(sizeof(char*)*num_elements);
  if(keys == NULL) {
    fprintf(stderr, "Fail to allocate space for keys\n");
    exit(1);
  }
  for(int i = 0; i < num_elements; i++) {
    keys[i] = malloc(sizeof(char)*6);
    if(keys[i] == NULL) {
      fprintf(stderr, "Fail to allocate space for a key\n");
      exit(1);
    }
    for(int j = 0; j < 5; j++) {
      keys[i][j] = rand() % 94 + 33;
    }
    keys[i][5] = '\0';
    elements[i].key = keys[i];
  }

  void* status;
  long lock_acq_time = 0;
  long t;
  int rc;
  pthread_t* threads = malloc(sizeof(pthread_t)*num_threads);
  if(threads == NULL) {
    fprintf(stderr, "Fail to allocate space for thread ID array\n");
    exit(1);
  }
  // notes the starting time for the run
  struct timespec start, end;
  clock_gettime(CLOCK_MONOTONIC, &start);

  // start the specified number of threads
  for(t = 0; t < num_threads; t++) {
    rc = pthread_create(&threads[t], NULL, thread_func, (void *) t);
    if (rc){
      fprintf(stderr, "ERROR; return code from pthread_create() is %d\n", rc);
      exit(1);
    }
  }
  
  // wait for all threads to complete
  for(t = 0; t < num_threads; t++) {
    rc = pthread_join(threads[t], &status);
    lock_acq_time += (long)status;
    if (rc) {
      fprintf(stderr, "ERROR; return code from pthread_join() is %d\n", rc);
      exit(1);
    }
  }

  // note the ending time for the run
  clock_gettime(CLOCK_MONOTONIC, &end);

  // checks the length of the list to confirm it is zero
  len = 0;
  for(int i = 0; i < num_lists; i++) {
    len = SortedList_length(&(sublists[i].head));
    if(len != 0){
      fprintf(stderr, "Final list length not zero\n");
      exit(2);
    }
  }

  // prints to stdout a comma-separated-value (CSV) record
  fprintf(stdout, "list-");
  if(opt_yield & INSERT_YIELD)
    fprintf(stdout, "i");
  if(opt_yield & DELETE_YIELD)
    fprintf(stdout, "d");
  if(opt_yield & LOOKUP_YIELD)
    fprintf(stdout, "l");
  if(opt_yield == 0)
    fprintf(stdout, "none");
  if(sync_opt == 'n')
    fprintf(stdout, "-none,");
  if(sync_opt == 's')
    fprintf(stdout, "-s,");
  if(sync_opt == 'm')
    fprintf(stdout, "-m,");
  long operations = num_threads*num_iter*3;
  long lock_operations = num_threads*(num_iter*2 + 1);
  long total_time = (end.tv_sec - start.tv_sec)*1000000000 + (end.tv_nsec - start.tv_nsec);
  fprintf(stdout, "%d,%d,%d,%ld,%ld,%ld", num_threads, num_iter, num_lists, operations, total_time, total_time/operations);
  if(sync_opt == 'n')
    fprintf(stdout, ",0\n");
  else
    fprintf(stdout, ",%ld\n", lock_acq_time/lock_operations);

  // cleaning up
  if(sync_opt == 'm') {
    for(int i = 0; i < num_lists; i++) {
      if(pthread_mutex_destroy(&(sublists[i].mutexlist)) != 0) {
	fprintf(stderr, "Fail to destroy mutex\n");
	exit(1);
      }
    }
  }
  free(elements);
  for(int i = 0; i < num_elements; i++) {
    free(keys[i]);
  }
  free(keys);
  free(sublists);
  exit(0);
}

